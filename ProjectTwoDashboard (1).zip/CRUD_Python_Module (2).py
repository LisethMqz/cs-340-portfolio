from pymongo import MongoClient

class AnimalShelter:
    def __init__(self, username, password,
                 host="localhost", port=27017,
                 db="aac", collection="animals"):

        uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource={db}"
        self.client = MongoClient(uri)
        self.database = self.client[db]
        self.collection = self.database[collection]

    def create(self, data):
        if data is not None and isinstance(data, dict):
            result = self.collection.insert_one(data)
            return result.acknowledged
        return False

    def read(self, query):
        if query is None:
            query = {}
        return list(self.collection.find(query, {"_id": False}))

    def update(self, query, new_values):
        if not query or not new_values:
            return 0
        result = self.collection.update_many(query, {"$set": new_values})
        return result.modified_count

    def delete(self, query):
        if not query:
            return 0
        result = self.collection.delete_many(query)
        return result.deleted_count
